//
//  contactUs.swift
//  
//
//  Created by Codebucketz on 7/9/19.
//

import Foundation
import UIKit

class contactUs: UIViewController, UIPopoverPresentationControllerDelegate {
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // All popover segues should be popovers even on iPhone.
        if let popoverController = segue.destination.popoverPresentationController,
            let button = sender as? UIButton {
            popoverController.delegate = self
            popoverController.sourceRect = button.bounds
        }
        
       /* guard let identifier = segue.identifier,
            let segueIdentifer = SegueIdentifier(rawValue: identifier) else { return }
            if segueIdentifer == .showObjects, let objectsViewController = segue.destination as? POpUpViewController {
            
        }
    */
    }
    
}
