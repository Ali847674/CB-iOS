//
//  slide.swift
//  demoAppEVE
//
//  Created by Codebucketz on 7/3/19.
//  Copyright © 2019 Codebucketz. All rights reserved.
//

import UIKit

class Slide: UIView {

    @IBOutlet weak var sliderImage: UIImageView!
    
    
   
}
