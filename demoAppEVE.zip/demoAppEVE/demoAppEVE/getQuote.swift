//
//  getQuote.swift
//  demoAppEVE
//
//  Created by predator on 7/6/19.
//  Copyright © 2019 Codebucketz. All rights reserved.
//

import Foundation
import UIKit

class getQuote: UIViewController {
    
    @IBAction func quoteRequested(_ sender: Any) {
        let alert = UIAlertController(title: "Done", message: "We will get back to you soon", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { _ in
            self.dismiss(animated: true, completion: nil)
            
        }))
    }
    
    
}
