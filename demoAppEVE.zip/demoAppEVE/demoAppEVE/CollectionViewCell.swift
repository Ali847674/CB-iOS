//
//  CollectionViewCell.swift
//  demoAppEVE
//
//  Created by predator on 7/10/19.
//  Copyright © 2019 Codebucketz. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageLabel: UIImageView!
    @IBOutlet weak var servicesLabel: UILabel!
    
}
