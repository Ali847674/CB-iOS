//
//  missionViewController.swift
//  demoAppEVE
//
//  Created by predator on 7/7/19.
//  Copyright © 2019 Codebucketz. All rights reserved.
//

import Foundation
import UIKit
import AVKit
import AVFoundation

class missionViewController: UIViewController {
    
    @IBOutlet weak var videoView: UIView!
    
    override func viewDidLoad() {
        
        let filePath = Bundle.main.path(forResource: "codebucketzVideo", ofType: "mp4")
        let player = AVPlayer(url: URL(fileURLWithPath: filePath!))
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = videoView.bounds
        videoView.contentMode = .scaleAspectFit
        videoView.layer.addSublayer(playerLayer)
        player.play()
        loopVideo(videoPlayer: player)
 
        
    }
    
    func loopVideo(videoPlayer: AVPlayer){

        NotificationCenter.default.addObserver(forName: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: nil, queue: nil) { Notification in
            videoPlayer.seek(to: kCMTimeZero)
            videoPlayer.play()
        }
        
    }
    
    
}
