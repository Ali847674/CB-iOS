//
//  servicesPage.swift
//  demoAppEVE
//
//  Created by predator on 7/10/19.
//  Copyright © 2019 Codebucketz. All rights reserved.
//

import Foundation
import UIKit

class servicesPage: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    let imageArray :[UIImage] = [
        UIImage(named: "logo")!,
        UIImage(named: "logo")!,
        UIImage(named: "logo")!,
        UIImage(named: "logo")!,
        UIImage(named: "logo")!,
        UIImage(named: "logo")!,
        UIImage(named: "logo")!,
    ]
    
    let text = ["Mobile Applications", "Desktop Applications", "Web Development", "E-commerce", "Branding", "Wordpress", "Game development"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        
        var layout = self.collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsetsMake(0,5,5,5)
        layout.minimumInteritemSpacing = 5
        layout.itemSize = CGSize(width: (self.collectionView.frame.size.width - 20) / 2, height: self.collectionView.frame.size.height / 2.5)
       
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollectionViewCell
        
        cell.imageLabel.image = imageArray[indexPath.item]
        cell.servicesLabel.text = text[indexPath.item]
        cell.layer.borderColor = UIColor.gray.cgColor
        cell.layer.borderWidth = 7.0
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.layer.borderColor = UIColor.black.cgColor
        cell?.layer.borderWidth = 0.5
    }
    
}
