//
//  pdfView.swift
//  demoAppEVE
//
//  Created by Codebucketz on 7/9/19.
//  Copyright © 2019 Codebucketz. All rights reserved.
//

import Foundation
import UIKit
import PDFKit

class  pdfView: UIViewController {
    
    
    @IBOutlet weak var pdfOutlet: PDFView!
    
    override func viewDidLoad() {
        
            pdfOutlet.autoScales = true
        
            let filePath = Bundle.main.url(forResource: "pdfFile", withExtension: "pdf")
            pdfOutlet.document = PDFDocument(url: filePath!)
        
            self.view.sendSubview(toBack: pdfOutlet)
    }
}

