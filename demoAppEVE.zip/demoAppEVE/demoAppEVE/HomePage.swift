//
//  HomePage.swift
//  demoAppEVE
//
//  Created by predator on 7/8/19.
//  Copyright © 2019 Codebucketz. All rights reserved.
//

import Foundation
import  UIKit

class homePage: UIViewController{
    
}
