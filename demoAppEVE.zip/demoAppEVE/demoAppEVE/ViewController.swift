//
//  ViewController.swift
//  demoAppEVE
//
//  Created by Codebucketz on 6/27/19.
//  Copyright © 2019 Codebucketz. All rights reserved.
//

import UIKit
import SideMenu

class ViewController: UIViewController, UITextFieldDelegate {
    
    
    
    @IBOutlet weak var userNameConstraint: NSLayoutConstraint!
    @IBOutlet weak var passwordConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var gifView: UIView!
    
    
    //loginSuccess variable
    var loginSuccess: Bool = false
    
    // Username and password text fields
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    
    //login and signup button propoerties
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signupButton: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        username.delegate = self
        password.delegate = self
        
        //login button properties
        loginButton.layer.borderColor = UIColor.white.cgColor
        loginButton.layer.shadowColor = UIColor.black.cgColor
        loginButton.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        loginButton.layer.shadowRadius = 0.5
        loginButton.layer.shadowOpacity = 0.5
        loginButton.layer.cornerRadius = loginButton.frame.width/5
        loginButton.layer.borderWidth = 0.5
        loginButton.layer.masksToBounds = false
        
        //signup button properties
        signupButton.layer.borderColor = UIColor.white.cgColor
        signupButton.layer.shadowColor = UIColor.black.cgColor
        signupButton.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        signupButton.layer.shadowRadius = 0.5
        signupButton.layer.shadowOpacity = 0.5
        signupButton.layer.cornerRadius = signupButton.frame.width/5
        signupButton.layer.borderWidth = 0.5
        signupButton.layer.masksToBounds = false
        
        //Adding gif to background
       
        
        let filePath = Bundle.main.path(forResource: "final_preloder", ofType: "gif")
        let gif = NSData(contentsOfFile: filePath!)
        
        
        let webViewBG = UIWebView(frame: self.view.frame)
        webViewBG.load(gif! as Data, mimeType: "image/gif", textEncodingName: "UTF-8", baseURL: NSURL() as URL)
        
        webViewBG.isUserInteractionEnabled = false
        webViewBG.center = self.view.center
        webViewBG.backgroundColor = UIColor.clear
        gifView.addSubview(webViewBG)
        gifView.sendSubview(toBack: webViewBG)
        
        let filter = UIView()
        filter.frame = self.view.frame
        filter.backgroundColor = UIColor.black
        filter.alpha = 0.10
        gifView.addSubview(filter)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(mainViewTapped))
        view.addGestureRecognizer(tapGesture)
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String?, sender: Any?) -> Bool {
        if let ident = identifier {
        if ident == "loginSegue" {
            return false
        }
        }
        return true
    }
    
    //login button function
    @IBAction func loginPressed(_ sender: Any) {
        shouldPerformSegue(withIdentifier: "loginSegue", sender: self)
        if(username.text != "") && (password.text != ""){
            if(username.text == "abcd@email.com") && (password.text == "12345"){
                loginSuccess = true
                
                performSegue(withIdentifier: "loginSegue", sender: self)
                
            }else {
                loginSuccess = false
                print("USERNAME or PASSWORD is EMPTY")
                //shouldPerformSegue(withIdentifier: "", sender: self)
                
                let alert = UIAlertController(title: "Alert", message: "Wrong username or password", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { _ in
                    self.dismiss(animated: true, completion: nil)
                }))
                self.present(alert,animated: true, completion: nil)
                
            }
        } else {
            
            let alert = UIAlertController(title: "Alert", message: "Enter username or password", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { _ in
                self.dismiss(animated: true, completion: nil)
            }))
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    
    //Setting keyboard to not overlap screen
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == username {
            userNameConstraint.constant = 280
        } else{
            passwordConstraint.constant = 250
        }
        view.layoutIfNeeded()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == username {
        userNameConstraint.constant = 16
        } else{
            passwordConstraint.constant = 8
        }
    }
    
    @objc func mainViewTapped(){
        username.endEditing(true)
        password.endEditing(true)
    }
    
}

